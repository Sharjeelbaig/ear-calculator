# ear-calculator

A Python module to compute Eye Aspect Ratio (EAR) from images.

## Installation

```bash
pip install ear-calculator
```
